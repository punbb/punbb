<?php

if (!defined('FORUM')) die();

$lang_default_avatar = array(
	'Default avatar'			=> 'Default avatar',
	'Default avatar url'		=> 'Default avatar URL'
)

?>